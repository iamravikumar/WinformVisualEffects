**List of supported languages :**
* English
* French
* Brazilian Portuguese (Eduardo Quintana)
* Dutch (Tim Musschoot)
* Arabic (khaledmahmoud123)