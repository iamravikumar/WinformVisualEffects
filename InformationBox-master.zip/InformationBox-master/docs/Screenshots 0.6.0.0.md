This page contains screenshots of the 0.6.0.0 release for the framework 2.0.


![A box with an existing icon, a help button, and the "Do not show this dialog again" checkbox](/docs/Screenshots%200.6.0.0_ErrorBoxCheckBoxHelpStandard.png)

_A box with an existing icon, a help button, and the "Do not show this dialog again" checkbox._

![The same box using the new style](/docs/Screenshots%200.6.0.0_ErrorBoxCheckBoxHelp.png)

_The same box using the new style._

![A typical About box](/docs/Screenshots%200.6.0.0_TypicalAboutBox.png)

_A typical About box._
