## Languages

You can contribute to this project by sending translations for a few words (mostly button names like OK or Cancel).

If you want to participate, just send me a message containing translation for these words :
* OK
* Cancel
* Retry
* Ignore
* Abort
* Yes
* No
* Help
* Do not show this dialog again

Please do not forget to include which language these translations apply to (and the language code if possible).
Do not forget to mention your name and website, they will be added on the contributors page (if you want).