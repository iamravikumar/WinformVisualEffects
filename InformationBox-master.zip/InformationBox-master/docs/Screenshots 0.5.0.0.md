This page contains screenshots of the release 0.5.0.0 for the framework 2.0.


![The designer main window](/docs/Screenshots%200.5.0.0_DesignerMain.png)

_The designer main window._

![A box with a new icon, a help button, and the "Do not show this dialog again" checkbox](/docs/Screenshots%200.5.0.0_HelpNewIconCheckBox.png)

_A box with a new icon, a help button, and the "Do not show this dialog again" checkbox._

![A box with a new predefined icon and custom buttons](/docs/Screenshots%200.5.0.0_CustomButtonsNewIcon.png)

_A box with a new predefined icon and custom buttons._
