The installation packages contain the HTML Help file. 

You can find some additional topic below:
* [Screenshots](Screenshots)
* [Samples](Samples)
* [Contributors](Contributors)
* [Contribute](Contribute)
* [InformationBox in action](InformationBox-in-action)
