This page contains screenshots of the release 0.4.1.0 for the framework 2.0.


![The designer main window](/docs/Screenshots%200.4.1.0_DesignerMain.png)

_The designer._

![A simple information box](/docs/Screenshots%200.4.1.0_SimpleInformation.png)

_A simple information box._

![A simple question box](/docs/Screenshots%200.4.1.0_SimpleQuestion.png)

_A simple question box._

![An error with multiline text and custom button placement](/docs/Screenshots%200.4.1.0_ErrorMultilineSeparate.png)

_An error message with a multiline text and a custom button placement (constant space)._

![Success box with right aligned buttons and custom button text](/docs/Screenshots%200.4.1.0_SuccessRightAlignedCustomButtons.png)

_Success box with right aligned buttons and custom button texts._

![A box with a custom icon, translated button texts, and button 2 as the default button](/docs/Screenshots%200.4.1.0_CustomIconTranslatedButton2.png)

_A box with a custom icon, translated button texts, and button 2 as the default button._
