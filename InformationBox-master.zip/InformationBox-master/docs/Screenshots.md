You have access to screenshots of several releases :
* [Screenshots of version 0.4.1.0](Screenshots%200.4.1.0.md)
* [Screenshots of version 0.5.0.0](Screenshots%200.5.0.0.md)
* [Screenshots of version 0.6.0.0](Screenshots%200.6.0.0.md)
