## Projects that use InformationBox
* DreamShield Installer : [http://smyley.developpez.com/programs/ms-net/dreamshield/windows/](http://smyley.developpez.com/programs/ms-net/dreamshield/windows/)