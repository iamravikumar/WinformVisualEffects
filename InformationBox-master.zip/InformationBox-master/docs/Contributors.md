**This page lists all those who have donated some of their time to help this project.**

## Features
* **jimgibbs** Opacity

## Translators

* **Eduardo Quintana** (Brazilian Portuguese)
* **Tim Musschoot** (Dutch)
* **khaledmahmoud123** (Arabic)