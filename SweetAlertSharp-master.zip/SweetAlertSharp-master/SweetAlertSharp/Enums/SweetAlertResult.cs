﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SweetAlertSharp.Enums
{
    public enum SweetAlertResult
    {
        OK,
        CANCEL,
    }
}
