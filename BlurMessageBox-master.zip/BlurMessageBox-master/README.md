# BlurMessageBox
The MessageBox form for WPF and WinForms application by ability to blurring that parent form

![ScreenShot.png](https://raw.githubusercontent.com/Behzadkhosravifar/BlurMessageBox/master/image/ScreenShot.PNG)
