﻿namespace BlurMessageBox
{
    public enum AnimateStyle
    {
        SlideDown = 1,
        FadeIn = 2,
        ZoomIn = 3
    }
}
