﻿namespace AhDung.WinForm
{
    partial class FmTester
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnShowMsgEx = new System.Windows.Forms.Button();
            this.txbResult = new System.Windows.Forms.TextBox();
            this.txbMessage = new System.Windows.Forms.TextBox();
            this.txbCaption = new System.Windows.Forms.TextBox();
            this.txbAttachMessage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.grpMsbButtons = new System.Windows.Forms.GroupBox();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.grpMsgIcon = new System.Windows.Forms.GroupBox();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.grpDfButton = new System.Windows.Forms.GroupBox();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.ckbEnableAnimate = new System.Windows.Forms.CheckBox();
            this.ckbEnableSound = new System.Windows.Forms.CheckBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.btnShowMsgStd = new System.Windows.Forms.Button();
            this.ckbExpand = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txbButtonsText = new System.Windows.Forms.TextBox();
            this.btnShowInfo = new System.Windows.Forms.Button();
            this.btnShowWarning = new System.Windows.Forms.Button();
            this.btnShowError = new System.Windows.Forms.Button();
            this.btnShowQuestion = new System.Windows.Forms.Button();
            this.grpMsbButtons.SuspendLayout();
            this.grpMsgIcon.SuspendLayout();
            this.grpDfButton.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnShowMsgEx
            // 
            this.btnShowMsgEx.Location = new System.Drawing.Point(12, 12);
            this.btnShowMsgEx.Name = "btnShowMsgEx";
            this.btnShowMsgEx.Size = new System.Drawing.Size(89, 23);
            this.btnShowMsgEx.TabIndex = 0;
            this.btnShowMsgEx.Text = "MsgBox";
            this.btnShowMsgEx.Click += new System.EventHandler(this.btnShowMsgEx_Click);
            // 
            // txbResult
            // 
            this.txbResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbResult.Location = new System.Drawing.Point(705, 35);
            this.txbResult.Multiline = true;
            this.txbResult.Name = "txbResult";
            this.txbResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txbResult.Size = new System.Drawing.Size(146, 521);
            this.txbResult.TabIndex = 13;
            this.txbResult.WordWrap = false;
            // 
            // txbMessage
            // 
            this.txbMessage.AcceptsReturn = true;
            this.txbMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbMessage.Location = new System.Drawing.Point(12, 153);
            this.txbMessage.Multiline = true;
            this.txbMessage.Name = "txbMessage";
            this.txbMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txbMessage.Size = new System.Drawing.Size(682, 49);
            this.txbMessage.TabIndex = 7;
            this.txbMessage.Text = "阿斯顿发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发阿斯顿发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发到发送到" +
    "发送到发送到发的萨芬送到发的萨芬";
            // 
            // txbCaption
            // 
            this.txbCaption.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbCaption.Location = new System.Drawing.Point(12, 100);
            this.txbCaption.Name = "txbCaption";
            this.txbCaption.Size = new System.Drawing.Size(682, 21);
            this.txbCaption.TabIndex = 6;
            this.txbCaption.Text = "阿斯顿发送到发送到发送到发送到";
            // 
            // txbAttachMessage
            // 
            this.txbAttachMessage.AcceptsReturn = true;
            this.txbAttachMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbAttachMessage.Location = new System.Drawing.Point(12, 229);
            this.txbAttachMessage.Multiline = true;
            this.txbAttachMessage.Name = "txbAttachMessage";
            this.txbAttachMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txbAttachMessage.Size = new System.Drawing.Size(682, 99);
            this.txbAttachMessage.TabIndex = 8;
            this.txbAttachMessage.Text = "阿斯顿发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发的萨芬\r\n阿斯顿发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到" +
    "发送到发的萨芬\r\n阿斯顿发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发送到发的萨芬";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(703, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "DialogResult：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "message:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "caption:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 12);
            this.label4.TabIndex = 5;
            this.label4.Text = "attach:";
            // 
            // grpMsbButtons
            // 
            this.grpMsbButtons.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.grpMsbButtons.Controls.Add(this.radioButton6);
            this.grpMsbButtons.Controls.Add(this.radioButton5);
            this.grpMsbButtons.Controls.Add(this.radioButton4);
            this.grpMsbButtons.Controls.Add(this.radioButton3);
            this.grpMsbButtons.Controls.Add(this.radioButton2);
            this.grpMsbButtons.Controls.Add(this.radioButton1);
            this.grpMsbButtons.Location = new System.Drawing.Point(14, 346);
            this.grpMsbButtons.Name = "grpMsbButtons";
            this.grpMsbButtons.Size = new System.Drawing.Size(165, 210);
            this.grpMsbButtons.TabIndex = 9;
            this.grpMsbButtons.TabStop = false;
            this.grpMsbButtons.Text = "buttons";
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(12, 181);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(89, 16);
            this.radioButton6.TabIndex = 5;
            this.radioButton6.Text = "RetryCancel";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(12, 149);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(53, 16);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.Text = "YesNo";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(12, 117);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(89, 16);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.Text = "YesNoCancel";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(12, 86);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(119, 16);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.Text = "AbortRetryIgnore";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(12, 55);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(71, 16);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "OKCancel";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(12, 24);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(35, 16);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "OK";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // grpMsgIcon
            // 
            this.grpMsgIcon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.grpMsgIcon.Controls.Add(this.radioButton11);
            this.grpMsgIcon.Controls.Add(this.radioButton10);
            this.grpMsgIcon.Controls.Add(this.radioButton9);
            this.grpMsgIcon.Controls.Add(this.radioButton8);
            this.grpMsgIcon.Controls.Add(this.radioButton7);
            this.grpMsgIcon.Location = new System.Drawing.Point(185, 346);
            this.grpMsgIcon.Name = "grpMsgIcon";
            this.grpMsgIcon.Size = new System.Drawing.Size(201, 210);
            this.grpMsgIcon.TabIndex = 10;
            this.grpMsgIcon.TabStop = false;
            this.grpMsgIcon.Text = "icon";
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(12, 149);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(155, 16);
            this.radioButton11.TabIndex = 4;
            this.radioButton11.Tag = "Information";
            this.radioButton11.Text = "Information / Asterisk";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(12, 117);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(149, 16);
            this.radioButton10.TabIndex = 3;
            this.radioButton10.Tag = "Warning";
            this.radioButton10.Text = "Warning / Exclamation";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(12, 86);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(71, 16);
            this.radioButton9.TabIndex = 2;
            this.radioButton9.Text = "Question";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(12, 55);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(137, 16);
            this.radioButton8.TabIndex = 1;
            this.radioButton8.Tag = "Error";
            this.radioButton8.Text = "Error / Stop / Hand";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Checked = true;
            this.radioButton7.Location = new System.Drawing.Point(12, 24);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(47, 16);
            this.radioButton7.TabIndex = 0;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "None";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // grpDfButton
            // 
            this.grpDfButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.grpDfButton.Controls.Add(this.radioButton14);
            this.grpDfButton.Controls.Add(this.radioButton13);
            this.grpDfButton.Controls.Add(this.radioButton12);
            this.grpDfButton.Location = new System.Drawing.Point(392, 346);
            this.grpDfButton.Name = "grpDfButton";
            this.grpDfButton.Size = new System.Drawing.Size(126, 210);
            this.grpDfButton.TabIndex = 11;
            this.grpDfButton.TabStop = false;
            this.grpDfButton.Text = "defaultButton";
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(12, 86);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(65, 16);
            this.radioButton14.TabIndex = 2;
            this.radioButton14.Text = "Button3";
            this.radioButton14.UseVisualStyleBackColor = true;
            this.radioButton14.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(12, 55);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(65, 16);
            this.radioButton13.TabIndex = 1;
            this.radioButton13.Text = "Button2";
            this.radioButton13.UseVisualStyleBackColor = true;
            this.radioButton13.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Checked = true;
            this.radioButton12.Location = new System.Drawing.Point(12, 24);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(65, 16);
            this.radioButton12.TabIndex = 0;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "Button1";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.RadioButtons_CheckedChanged);
            // 
            // ckbEnableAnimate
            // 
            this.ckbEnableAnimate.AutoSize = true;
            this.ckbEnableAnimate.Checked = true;
            this.ckbEnableAnimate.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbEnableAnimate.Location = new System.Drawing.Point(235, 16);
            this.ckbEnableAnimate.Name = "ckbEnableAnimate";
            this.ckbEnableAnimate.Size = new System.Drawing.Size(102, 16);
            this.ckbEnableAnimate.TabIndex = 2;
            this.ckbEnableAnimate.Text = "EnableAnimate";
            this.ckbEnableAnimate.UseVisualStyleBackColor = true;
            this.ckbEnableAnimate.CheckedChanged += new System.EventHandler(this.ckbEnableAnimate_CheckedChanged);
            // 
            // ckbEnableSound
            // 
            this.ckbEnableSound.AutoSize = true;
            this.ckbEnableSound.Checked = true;
            this.ckbEnableSound.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbEnableSound.Location = new System.Drawing.Point(350, 16);
            this.ckbEnableSound.Name = "ckbEnableSound";
            this.ckbEnableSound.Size = new System.Drawing.Size(90, 16);
            this.ckbEnableSound.TabIndex = 3;
            this.ckbEnableSound.Text = "EnableSound";
            this.ckbEnableSound.UseVisualStyleBackColor = true;
            this.ckbEnableSound.CheckedChanged += new System.EventHandler(this.ckbEnableSound_CheckedChanged);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(578, 17);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(107, 12);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "written by AhDung";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // btnShowMsgStd
            // 
            this.btnShowMsgStd.Location = new System.Drawing.Point(107, 12);
            this.btnShowMsgStd.Name = "btnShowMsgStd";
            this.btnShowMsgStd.Size = new System.Drawing.Size(89, 23);
            this.btnShowMsgStd.TabIndex = 1;
            this.btnShowMsgStd.Text = "MessageBox";
            this.btnShowMsgStd.Click += new System.EventHandler(this.btnShowMsgStd_Click);
            // 
            // ckbExpand
            // 
            this.ckbExpand.AutoSize = true;
            this.ckbExpand.Location = new System.Drawing.Point(458, 16);
            this.ckbExpand.Name = "ckbExpand";
            this.ckbExpand.Size = new System.Drawing.Size(60, 16);
            this.ckbExpand.TabIndex = 4;
            this.ckbExpand.Text = "expand";
            this.ckbExpand.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(524, 346);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "buttonsText";
            // 
            // txbButtonsText
            // 
            this.txbButtonsText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbButtonsText.Location = new System.Drawing.Point(524, 364);
            this.txbButtonsText.Multiline = true;
            this.txbButtonsText.Name = "txbButtonsText";
            this.txbButtonsText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txbButtonsText.Size = new System.Drawing.Size(170, 192);
            this.txbButtonsText.TabIndex = 12;
            this.txbButtonsText.Text = "1st btn\'s custom Text(&O)\r\n\r\n3rd\r\nunnecessary\r\nunnecessary";
            this.txbButtonsText.WordWrap = false;
            // 
            // btnShowInfo
            // 
            this.btnShowInfo.Location = new System.Drawing.Point(12, 44);
            this.btnShowInfo.Name = "btnShowInfo";
            this.btnShowInfo.Size = new System.Drawing.Size(79, 20);
            this.btnShowInfo.TabIndex = 14;
            this.btnShowInfo.Text = "ShowInfo";
            this.btnShowInfo.UseVisualStyleBackColor = true;
            this.btnShowInfo.Click += new System.EventHandler(this.btnShowInfo_Click);
            // 
            // btnShowWarning
            // 
            this.btnShowWarning.Location = new System.Drawing.Point(93, 44);
            this.btnShowWarning.Name = "btnShowWarning";
            this.btnShowWarning.Size = new System.Drawing.Size(79, 20);
            this.btnShowWarning.TabIndex = 14;
            this.btnShowWarning.Text = "ShowWarning";
            this.btnShowWarning.UseVisualStyleBackColor = true;
            this.btnShowWarning.Click += new System.EventHandler(this.btnShowWarning_Click);
            // 
            // btnShowError
            // 
            this.btnShowError.Location = new System.Drawing.Point(174, 44);
            this.btnShowError.Name = "btnShowError";
            this.btnShowError.Size = new System.Drawing.Size(79, 20);
            this.btnShowError.TabIndex = 14;
            this.btnShowError.Text = "ShowError";
            this.btnShowError.UseVisualStyleBackColor = true;
            this.btnShowError.Click += new System.EventHandler(this.btnShowError_Click);
            // 
            // btnShowQuestion
            // 
            this.btnShowQuestion.Location = new System.Drawing.Point(255, 44);
            this.btnShowQuestion.Name = "btnShowQuestion";
            this.btnShowQuestion.Size = new System.Drawing.Size(87, 20);
            this.btnShowQuestion.TabIndex = 14;
            this.btnShowQuestion.Text = "ShowQuestion";
            this.btnShowQuestion.UseVisualStyleBackColor = true;
            this.btnShowQuestion.Click += new System.EventHandler(this.btnShowQuestion_Click);
            // 
            // FmMsgBoxExTester
            // 
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(863, 582);
            this.Controls.Add(this.btnShowQuestion);
            this.Controls.Add(this.btnShowError);
            this.Controls.Add(this.btnShowWarning);
            this.Controls.Add(this.btnShowInfo);
            this.Controls.Add(this.txbButtonsText);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ckbExpand);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.ckbEnableSound);
            this.Controls.Add(this.ckbEnableAnimate);
            this.Controls.Add(this.grpDfButton);
            this.Controls.Add(this.grpMsgIcon);
            this.Controls.Add(this.grpMsbButtons);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txbAttachMessage);
            this.Controls.Add(this.txbCaption);
            this.Controls.Add(this.txbMessage);
            this.Controls.Add(this.txbResult);
            this.Controls.Add(this.btnShowMsgStd);
            this.Controls.Add(this.btnShowMsgEx);
            this.Name = "FmMsgBoxExTester";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "MsgBoxTester";
            this.grpMsbButtons.ResumeLayout(false);
            this.grpMsbButtons.PerformLayout();
            this.grpMsgIcon.ResumeLayout(false);
            this.grpMsgIcon.PerformLayout();
            this.grpDfButton.ResumeLayout(false);
            this.grpDfButton.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnShowMsgEx;
        private System.Windows.Forms.TextBox txbResult;
        private System.Windows.Forms.TextBox txbMessage;
        private System.Windows.Forms.TextBox txbCaption;
        private System.Windows.Forms.TextBox txbAttachMessage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grpMsbButtons;
        private System.Windows.Forms.GroupBox grpMsgIcon;
        private System.Windows.Forms.GroupBox grpDfButton;
        private System.Windows.Forms.CheckBox ckbEnableAnimate;
        private System.Windows.Forms.CheckBox ckbEnableSound;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button btnShowMsgStd;
        private System.Windows.Forms.CheckBox ckbExpand;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbButtonsText;
        private System.Windows.Forms.Button btnShowInfo;
        private System.Windows.Forms.Button btnShowWarning;
        private System.Windows.Forms.Button btnShowError;
        private System.Windows.Forms.Button btnShowQuestion;
    }
}